
<!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h1>Selamat Datang, <?php echo $_SESSION['wisataku']['nama_admin']; ?></h1>
        <p>Di Website Admin Wisataku</p>
          <a class="btn btn-lg btn-primary" href="index.php?page=data-wisata" role="button">Lihat Wisata &raquo;</a>
        </p>
      </div>
