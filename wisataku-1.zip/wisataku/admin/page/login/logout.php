<?php
session_start();

$_SESSION['wisataku'] = array();

header("location:login.php");
?>