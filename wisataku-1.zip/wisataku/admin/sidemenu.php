        <div class="row">
            <div class="col-md-2 sidebar">
                <ul class="nav nav-pills nav-stacked">
                    <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                    <li><a href="index.php?page=data-admin">Data Admin</a></li>
                    <li><a href="index.php?page=data-wisata">Data Wisata</a></li>
                    <!-- <li><a href="#">Data Pembelian</a></li> -->
                </ul>
            </div>
        </div>