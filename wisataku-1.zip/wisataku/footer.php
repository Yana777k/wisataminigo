<!-- FOOTER -->
<footer>
    <p class="pull-right"><a href="#">Back to top</a></p>
    <p>&copy; 2023 since, Inc. &middot; <a href="/admin/page/login/login.php">Link</a> &middot; <a href="#">Terms</a></p>
  </footer>

  </div>
</body>