<?php include 'header.php'; ?>
<div class="container-fluid">
    <div class="row">
        <div class="container konten">
            <div class="panel panel-default">
                <div class="panel-body main">
                    <div class="col-md-8">
                        <div class="about">
                            <div class="row post-title">
                                <div class="col-sm-12">
                                    <h2>Tentang Wisataku</h2>
                                </div>
                            </div>
                            <div class="row post-content">
                                <div class="col-sm-12">
                                    <p>Wisataku adalah sebuah website yang menyediakan berbagai macam tiket wisata cuy</p>
                                    <p>Website ini diciptakan buat tugas rpl web </p>
                                    <h3>Creator: Rezell yana ido agi</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logo col-md-4">
                        <img class="img-profile rounded-circle animate__animated animate__fadeIn" src="admin/image/logo/ucing.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>

